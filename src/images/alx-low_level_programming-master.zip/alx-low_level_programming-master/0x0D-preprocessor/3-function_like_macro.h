#ifndef FUNCITION_LIKE_MACRO_H
#define FUNCITION_LIKE_MACRO_H
#define ABS(x) ((x < 0) ? (x) * (-1) : (x))
#endif

#include "main.h"
/**
 *mul - multiplies two ints.
 *@a: integer.
 *@b: integer.
 *
 *Return: product.
 */
int mul(int a, int b)
{
	int product;

	product = a * b;
	return (product);
}

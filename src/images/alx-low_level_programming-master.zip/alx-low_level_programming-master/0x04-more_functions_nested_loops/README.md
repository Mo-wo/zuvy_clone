Learning Functions and Loops in C

This project is the first C project as part of the Holberton School curriculum, and covers the very basics of compilation and C.

Added: C - More pointers, arrays and strings

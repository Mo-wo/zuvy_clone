Introduction to C - malloc, free

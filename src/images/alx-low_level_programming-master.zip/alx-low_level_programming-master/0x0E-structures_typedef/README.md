C - Structures, typedef

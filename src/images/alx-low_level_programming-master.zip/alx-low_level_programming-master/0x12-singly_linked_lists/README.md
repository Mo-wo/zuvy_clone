C - Singly linked lists

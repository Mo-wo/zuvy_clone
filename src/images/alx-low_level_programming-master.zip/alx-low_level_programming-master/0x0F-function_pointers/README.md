C - Function pointers

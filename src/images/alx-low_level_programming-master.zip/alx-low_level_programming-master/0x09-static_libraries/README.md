Introduction to C - Static libraries

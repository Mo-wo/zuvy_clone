 File 0-positive_or_negative.c is a C program that will assign a random number to the variable n each time it is executed, using an if statement.

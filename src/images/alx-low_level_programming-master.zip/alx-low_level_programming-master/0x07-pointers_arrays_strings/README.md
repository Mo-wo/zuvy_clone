 Even more pointers, arrays and strings

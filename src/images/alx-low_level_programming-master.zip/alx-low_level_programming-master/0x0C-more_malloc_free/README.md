Introduction to C - More malloc, free

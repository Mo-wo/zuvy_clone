C - Variadic functions

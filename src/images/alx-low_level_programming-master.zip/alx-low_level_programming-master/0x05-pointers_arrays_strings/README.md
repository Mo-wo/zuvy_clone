Introduction to Pointers, arrays and strings
